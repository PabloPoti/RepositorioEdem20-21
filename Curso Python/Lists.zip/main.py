#Lists

list1 = [1, 2, 3, 4, 5]
list1[0] = 10
print(list1)

list1 = [10, 11, 12, 13, 14]
print(list1[::3])

list1 = [1, 2, 3, 4, 5]
print(list1[4])

numbers = [1, 2, 3, 4, 5]
numbers[4] = 6
print(numbers[4])

#ListMethods

num = [4, 4, 3, 1]
num.sort()
print(num)

list1=["Go","Java","C","Rust"]
print(min(list1))

list1 = [10, 20, 30, 40, 50]
list1.append(60)
print(list1)

ages = [56, 72, 24, 46]
ages.sort()
print(ages)

list1=["Go","Java","C","Python"]
print(max(list1))

list1 = [4, 4, 3, 1]
list1.pop(2)
print(list1)

list1=['UK','India','Canada']

list1.insert(1,8)

print(list1)

#IteratingLists

for letter in 'KodeKloud':
    if letter == 'e':
        continue
    print('Letter : ' + letter)

for letter in 'KodeKloud':
    if letter == 'u':
        continue
    print('Letter : ' + letter)

sum = 0
values = [2,9,1,7]
for number in values:
    sum = sum + number

print(sum)

for x in [0, 1, 1, 3]:
    for y in [0, 2, 1, 2]:
            print('*')

for x in [0, 2, 1, 3]:
    for y in [0, 4, 1, 2]:
            print('*')

sum = 0
values = [2,9,1,7]
for number in values:
    sum += number

print(sum)



#UnderstandingLists

