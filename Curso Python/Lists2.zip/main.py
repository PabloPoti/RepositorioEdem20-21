#UnderstandingLists

list1 = [1, 2, 3, 4]
for index, j in enumerate(list1):
     print(index, j)

list1 = [10, 11, 12, 13, 14]
print(list1[0])

letters = ["A", "B", "C", "D", "E"]
print(letters[1:])

list1=[4,0,7,1]
print(list1[::-1])

list1 = [[1,2,3,2,5],[4,5,6,7],[8,9,10]]
for i in list1:
      if len(i)==4:
        print(i)

list1 = [[1,2,3,2,5],[4,5,6,7],[8,9,10]]
for i in list1:
      if len(i)==3:
        print(i)

list1 = [1, 2, 3, 4]
for i, j in enumerate(list1):
     print(i, j)

list1 = [10, 11, 12, 13, 14]
print(list1[::1])

list1 = [10, 11, 12, 13, 14]
list1.append(15)
print(list1)

#SlicingLists

my_list = [0, 1, 2, 3, 4]
print(my_list[::2])

list1 = [1, 66, "python", [11, 55, "cat"], [ ], 2.22, True]
print(list1[0:4])

'''
list1 = [1, 66, "python", [11, 55, "cat"], [ ], 2.22, True]
print(list1.upper())
'''

my_list = [0, 1, 2, 3, 4]
print(my_list[::3])

my_list = [0, 1, 2, 3, 4]
print(my_list[::-1])

my_list = [0, 1, 2, 3, 4]
my_list.append("python")
print(my_list[2:])

my_list = [0, 1, 2, 3, 4]
my_list.append("python")
b = my_list[1:]
print(b)

my_list = [0, 1, 2, 3, 4]
print(my_list[-1])

list1 = [1, 66, "python", [11, 55, "cat"], [ ], 2.22, True]
print(list1[2:4])

my_list = [0, 1, 2, 3, 4]
print(my_list[2:4])

#FindingInLists

my_list = [0, 1, 2, 3, 4]
print(my_list.index(2))

countries = ["USA", "Canada", "India"]
countries[0], countries[1] = countries[1], countries[0]
print(countries)

list1 = [0, 3, 4, 1, 2]
list1[2:5]=[8,9]
print(list1)

list1=[3,4,6,1,2]
list2=list1
list1[1]=9
print(list2)

list1 = [0, 3, 4, 1, 2]
list1[1]=[8,9]
print(list1)

(4, 6) not in [(4, 7), (5, 6), "hello"]

my_list = [0, 3, 4, 1, 2]
print(my_list.index(1))

list1=[3,4,6,1,2]
list2=list1
list1[0]=9
print(list2)

list1 = [0, 3, 4, 1, 2]
list1[2:4]=[1,2]
print(list1)

list1 = [0, 3, 4, 1, 2]
list1[2:4]=[1,2]
print(list1)

Li = ['A','C','b', 1, 3, 4]


#NestedLists–2D

a = []
for i in range(5):
    a.append([])
    for j in range(5):
        a[i].append(j)

print(a[2][3])

a = []
for i in range(2):
    a.append([])
    for j in range(2):
        a[i].append(j)

print(a)

a = []
for i in range(5):
    a.append([])
    for j in range(5):
        a[i].append(j)

print(a[3][3])

countries = [['Egypt', 'USA', 'India'],
       ['Dubai', 'America', 'Spain'], 
       ['London', 'England', 'France']]
countries2  = [country for sublist in countries for country in 
                       sublist if len(country) < 6]
print(countries2)

matrix = [[j for j in range(4)] for i in range(4)] 
print(matrix[3][1])

matrix = [[j for j in range(3)] for i in range(3)] 
print(matrix[2][1])

matrix = [[j for j in range(3)] for i in range(3)] 
print(matrix[1][2])

matrix = [[0, 1, 2], [0, 1, 2], [0, 1, 2]]

matrix2 = []

for submatrix in matrix:
  for val in submatrix:
    matrix2.append(val)

print(matrix2[2])

matrix = [[0, 1, 2], [0, 1, 2], [0, 1, 2]]

matrix2 = []

for submatrix in matrix:
  for val in submatrix:
    matrix2.append(val)

print(matrix2[0])

countries = [['Egypt', 'USA', 'India'], ['Dubai', 'America', 'Spain'], ['London', 'England', 'France']]
countries2  = [country for sublist in countries for country in sublist if len(country) < 4]
print(countries2)


#NestedLists–3D

Colors = [ ['Red', 'Green', 'White', 'Black'], ['Green', 'Blue', 'White', 'Yellow'] ,['White', 'Blue', 'Green', 'Red'] ]

matrix = [[[k for k in range(3)] for j in range(3)] for i in range(3)]
print(matrix[1][2])

Colors= [ [['Blue','Green','White','Black']], [['Green','Blue','White','Yellow']] , [['White','Blue','Red','Green']] ]

matrix = [[[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]]]

matrix2 = []

for submatrix in matrix:
  for val in submatrix:
    matrix2.append(val)

print(matrix2[2][0])

matrix = [[[k for k in range(3)] for j in range(3)] for i in range(3)]
print(matrix[0][0][1])

matrix = [[[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]]]
print(matrix[0][0][0])

matrix = [[[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]]]

matrix2 = []

for submatrix in matrix:
  for val in submatrix:
    matrix2.append(val)

print(matrix2[2])

matrix = [[[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]], [[0, 1, 2], [0, 1, 2], [0, 1, 2]]]

matrix2 = []

for submatrix in matrix:
  for val in submatrix:
    matrix2.append(val)

print(matrix2[2][2])

matrix = [[[k for k in range(3)] for j in range(3)] for i in range(3)]
print(matrix[2][1])

matrix = [[[k for k in range(3)] for j in range(3)] for i in range(3)]
print(matrix[1][1][1])