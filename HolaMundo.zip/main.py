nombre:str = "Pablo"
saludo = f'¡Hola, {nombre}!'

print('¡Hola, '+nombre+'!')
print(f'¡Hola, {nombre}!')
print(saludo)

'''
Esto es un comentario multilínea
'''


# Esto sería una línea de comentario
# TODO: Tarea pendiente de hacerse
# FIXME: Correcciones de código necesarias


'''
TIPOS DE DATOS EN PYTHON
'''

print('-----CADENAS DE TEXTO-----')

# STR
miCadena: str = "Hola Mundo"
miCadena2: str= '''Hola Mundo'''

primeros_dos_caracteres= miCadena[0:2]

print(f'PRIMEROS DOS CARACTERES: {primeros_dos_caracteres}')

print(f'Texto con Mayúsculas: {miCadena.upper()}')
print(f'Texto con Minúsculas: {miCadena.lower()}')
print(f'Texto Capitalizado: {miCadena.capitalize()}')

'''
BOOL
'''
casado:bool = False

print(f'¿Casado? {casado}')

'''
LISTAS de Datos
'''

miLista: [str] = ['Martín', 'Juan', 'Ana',]
print(miLista)
# Con un * obtenemos la representación real de cada valor
print(*miLista)
# Mostrar el valor 2 (se empieza por el 0)
print(miLista[2])

# Rangos
miRango = range(1, 10, 2)
# El tercer número del paréntesis (2) hará que se muestre uno sí y otro no
miRango2 = range(10, 1, -2)
miRango3 = range(-10, 10, 2)

print(*miRango)
print(*miRango2)
print(*miRango3)

'''
DICCIONARIOS
'''

persona = {
  "nombre": "Pablo",
  "edad": 24,
  "email": "pablosanchezsaez@gmail.com"
}

print(persona)
print(*persona)

# A continuación se ven dos formas para hacer lo mismo:
print(f'La edad de {persona["nombre"]} es {persona.get("edad")}')

# La esencia del SET es que no se repetirán los datos

misNumeros = [1,2,3,4,5,1,5]
print(*misNumeros)

miSetDeNumeros = set([1,2,3,4,5,1,5])
print(miSetDeNumeros)
miOtroSetDeDatos = {1,2,2,5,5,'a', False}
print(miOtroSetDeDatos)

miSetCongelado = frozenset(misNumeros)

miValorNone = None

print(miValorNone)


'''
str
int
float
complex
list
tuple
range
dict
set
frozenset
bool
bytes
bytearray
memoryview
'''




'''
RETO 1

Operación aritmética que realice

|(6-2) |^2
|----- |
|  5   |


'''

resultado_operacion:float = ((6-2)/5)**2
print(resultado_operacion)
print(resultado_operacion.__round__(2))

'''
RETO GRUPAL

Partiendo de:
- cantidad a invertir
- el interés anual
- el número de años

Calcular el capital obtenido y guardarlo en una variable

se tiene que mostrar por consola
el capital obtenido por tu inversión asciende a "capital obtenido €"

'''

inv = 10000
rent = 10
n = 40

patrimonio=inv*(1+(rent/100))**n

print(f'El capital obtenido por tu inversion asciende a {round (patrimonio,2)} €')

'''
RETO GRUPAL 2

· Producto cuyo valor es de 14,99€

· Los que no son de temporada tendrán 30% de descuento

Reciba un número de productos en temporada. Otro número de productos de la temporada pasada y aplicar el descuento para obtener el gasto total.

También hay que indicar la cantidad ahorrada gracias al descuento

'''

precio = 14.99
descuento = 30
print('¿Cuántos productos de temporada has comprado')
temp=int(input())
print('¿Cuántos productos fuera de temporada has comprado')
noTemp=int(input())

total=temp*precio+noTemp*precio*((100-descuento)/100)
print(f'El total asciende a {round (total,2)} €')

'''
RETO GRUPAL 3
1º se pide al usuario un año
2º se dice si es bisiesto o no
'''
print('Dime un año y te diré si es bisiesto o no')
año=int(input())

if año % 4 != 0: #no divisible entre 4
	print("No es bisiesto")
elif año % 4 == 0 and año % 100 != 0: #divisible entre 4 y no entre 100 o 400
	print("Es bisiesto")
elif año % 4 == 0 and año % 100 == 0 and año % 400 != 0: #divisible entre 4 y 10 y no entre 400
	print("No es bisiesto")
elif año % 4 == 0 and año % 100 == 0 and año % 400 == 0: #divisible entre 4, 100 y 400
	print("Es bisiesto")

'''
RETO GRUPAL 4
1º el usuario tiene que escribir un año hasta que sea bisiesto
'''


year = int(input("Introduce un año: "))
if (year % 4) == 0 & (year % 400) == 0:
  if (year % 100) != 0:
    print(f'El año {year} es bisiesto')
else:
  print(f'El año {year} no es bisiesto')

# Versión con el bucle

while True:
  year = int(input("Introduce un año: "))
  if (year % 4) == 0 & (year % 100 != 0 | year % 400 == 0):
    print(f'El año {year} es bisiesto')
    break
  else:
    print(f'El año {year} no es bisiesto. Vuelve a intentarlo.')


'''
RETO GRUPAL 5

Consola le pide al usuario sobre una película
· Nombre (str)
· Año (int)
· Puntuación (float) --> puede ser [1,5]
· Director
· Género --> comedia o terror o acción o drama

y todo guardado en un diccionario --> Película favorita

'''