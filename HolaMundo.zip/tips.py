'''
Esto es un comentario multilínea
'''


# Esto sería una línea de comentario
# TODO: Tarea pendiente de hacerse
# FIXME: Correcciones de código necesarias

# Los números enteros se establecen como int# Pueden ser tanto positivos como negativos
edad:int = 28puntos: int = -30


# Las datos con decimales en Python se establecen como float
temperatura:float = 10.5
media_notas:float = 9.80


# Los Booleanos en Python se tipan a través de bool# Solamente pueden ser True o False
casado: bool = True
con_hijos: bool = False


# Los diccionarios sirven para almacenar datos en formato de clave - valor# Se delimitan a través de llaves { ... }
miDiccionario = dict()

miDiccionario = {
  "nombre": "Martin",
  "apellidos": "San José",
  "edad": 28,
  "email": "masajo@edem.es"
}


# Las tuplas son estáticas y no pueden cambiar su tamaño
miTupla = (5, "Hola mundo!", True, -4.5)


miListaDeContactos: [str] = ['Martín', 'Alberto', 'Sofía']
miListaDeDatosCombinados = [42, 3.14, 'hola', 25, False,(1, 2), {1:"uno", 2:"dos"}]


'''
En Python no disponemos de una palabra reservada para las constantes (valores inamovibles),así que simplemente las pondremos en MAYÚSCULAS por convención
'''
NUMERO_PI = 3.141516