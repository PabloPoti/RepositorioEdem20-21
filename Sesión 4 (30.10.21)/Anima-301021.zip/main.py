from animal import Animal
from alimentacion.carnivoro import Carnivoro
from alimentacion.herbivoro import Herbivoro
from alimentacion.omnivoro import Omnivoro

Perro:Animal = Animal('7',4,'ladra muy fuerte.','Pluto')

Perro.hacerRuido()
Perro.comer(2)

Gato:Herbivoro = Animal('12',4,'maúlla todas las noches hasta que se duerme.','Lucifer')

Gato.hacerRuido()
Gato.comer(1)

Suricato:Carnivoro = Carnivoro('2',4,'corre, husmea y acecha.','Timón')

Suricato.hacerRuido()
Suricato.comer(0.2)

Rinoceronte:Herbivoro = Herbivoro('12',4,'embiste con poder.','Rino')

Rinoceronte.hacerRuido()
Rinoceronte.comer(50)

Humano:Omnivoro = Omnivoro('24',2,'programa en Python.','Pablo')

Humano.hacerRuido()
Humano.comer(3)