from animal import Animal


class Omnivoro(Animal):
  tipo:str= 'todo tipo de alimentos'

  def __init__(self,edad,npatas,ruido,nombre):
    super(Omnivoro, self).__init__(edad, npatas, ruido, nombre)

  def comer(self,kilos):
    self.KComida += kilos
    print (f'{self.nombre} ha comido {kilos} kilos. Durante el día ha comido {self.KComida} kilos de {self.tipo}.\n')
    