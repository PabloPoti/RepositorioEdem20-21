from animal import Animal


class Herbivoro(Animal):
  tipo:str= 'hierbajos'

  def __init__(self,edad,npatas,ruido,nombre):
    super(Herbivoro, self).__init__(edad, npatas, ruido, nombre)

  def comer(self,kilos):
    self.KComida += kilos
    print (f'{self.nombre} ha comido {kilos} kilos. Durante el día ha comido {self.KComida} kilos de {self.tipo}.\n')
    