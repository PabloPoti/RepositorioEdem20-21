from animal import Animal


class Carnivoro(Animal):
  tipo:str= 'carne'

  def __init__(self,edad,npatas,ruido,nombre):
    super(Carnivoro, self).__init__(edad, npatas, ruido, nombre)

  def comer(self,kilos):
    self.KComida += kilos
    print (f'{self.nombre} ha comido {kilos} kilos. Durante el día ha comido {self.KComida} kilos de {self.tipo}.\n')
    