class Animal:
    edad: int
    npant: int
    ruido: str
    nombre: str
    KComida: int = 0

    # parámetros de la clase animal
    def __init__(self,edad,npatas,ruido,nombre):
      self.edad = edad
      self.npatas = npatas
      self.ruido = ruido
      self.nombre = nombre

    def hacerRuido(self):
      print (f'{self.nombre} {self.ruido}')

    def comer(self, kilos:int):
          self.KComida += kilos
          print(f'{self.nombre} ha comido {kilos} kilos. Durante el día ha comido {self.KComida} kilos.\n')

    