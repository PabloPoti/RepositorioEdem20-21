	
from math import sqrt, sin, cos
 
numero: int = 16
  
print(f'La raíz cuadrada de {numero} es {sqrt(numero)}') #imprime 4.0
print(f'El Seno de {numero} es {sin(numero)}') #imprime -0.287...
print(f'El Coseno de {numero} es {cos(numero)}') #imprime -0.957...
