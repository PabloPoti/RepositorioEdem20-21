#Archivo main.py
from HTTP_Requests.chuck_norris_dice import obtenerChiste
 
#Lo ejecutamos
obtenerChiste()