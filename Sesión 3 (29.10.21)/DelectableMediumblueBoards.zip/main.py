from math import sqrt as raiz, sin as seno, cos #Alias para coseno si no seria cos as coseno 
 
numero: int = 16
  
print(f'La raíz cuadrada de {numero} es {raiz(numero)}') #imprime 4.0
print(f'El Seno de {numero} es {seno(numero)}') #imprime -0.287...
print(f'El Coseno de {numero} es {cos(numero)}') #imprime -0.957...

# Para que se ejecute el archivo cordilidad.py hay que importarlo ( llamarlo a ejecutarejecutarlo) en main.py 

from cordialidad import saludar

saludar('Jose')


# Paquetes .py

#Archivo main.py
from utilidades.interacciones.cordialidad import saludar
from utilidades.kpis import puntuacion
 
puntos = puntuacion(0)
 
print(f'{saludar("Pedro")} tu puntuación es de {puntos}')