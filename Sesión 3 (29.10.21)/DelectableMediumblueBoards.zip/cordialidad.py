#Archivo cordialidad.py
 
def saludar(nombre: str):
  print(f'Hola {nombre}')