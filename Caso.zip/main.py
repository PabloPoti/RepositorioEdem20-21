def reto4Basico():
  lista: [int] = [1,2,3,4,5]
  lista_inversa: [int] = reversed(lista)

  print(lista_inversa)

  for i in lista_inversa:
      print(f"- {i}")