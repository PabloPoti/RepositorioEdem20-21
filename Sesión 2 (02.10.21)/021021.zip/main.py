

'''¡Palabras clave en Python!
Estas palabras no se deben usar si no es para el uso que tiene el lenguaje establecido

- and
- as
- assert
- break
- class
- continue
- def
- del
- elif
- else
- except
- exec
- finally
- for
- from
- global
- if
- import
- in
- is
- lambda
- nonlocal
- not
- or
- pass
- raise
- return
- try
- while
- with
- yield
- True
- False
- None
'''

'''
OPERADORES
'''
# Operadores Numéricos
operacion_compleja = 33 * 10 + 2 / 5 ** 2
print(f"> Operación 33*10+2/5**2 = {operacion_compleja}")
operacion_compleja_2 = (33 * 10) + (2 / (5 ** 2))
print(f"> Operación (33*10)+(2/(5**2)) = {operacion_compleja_2}")
operacion_compleja_3 = (33 * 10) + (2 / 5) ** 2
print(f"> Operación (33*10)+(2/5)**2 = {operacion_compleja_3}")

nombre: str = "Martín"
apellidos: str = "San José de Vicente"  
# Concatenación
nombre_completo: str = nombre + " " + apellidos
print(f"> Nombre completo: {nombre_completo}")  
# Repetición
nombre_x5: str = nombre*5
print(f"> Nombre 5 veces: {nombre_x5}")

c: int = 3
d: int = 3
e: int = 4

# Igualdad - Nos devolverá True o False
print(f"> ¿3 y 3 son iguales? {c is d}") # Operador Identidad
print(f"> ¿3 y 3 son iguales? {c == d}")
print(f"> ¿3 y 4 son iguales? {c is e}")  # Operador Identidad

# Desigualdad - Nos devolverá True o False
print(f"> ¿3 y 3 no son iguales? {c is not d}") # Operador Identidad
print(f"> ¿3 y 4 no son iguales? {c is not e}") # Operador Identidad
print(f"> ¿3 y 3 no son iguales? {c != d}")

# And (y)
print(f"> Verdadero y Verdadero = {True and True}")
print(f"> Verdadero y Falso = {True and False}")
print(f"> Verdadero y 1 = {True and 1}")
print(f"> Falso y Falso = {False and False}")
print(f"> Falso y 0 = {False and 0}")
print(f"> Falso y None = {False and None}")
# Or (ó)
print(f"> Verdadero o Verdadero = {True or True}")
print(f"> Verdadero o Falso = {True or False}")
print(f"> Falso o False = {False or False}")
# Not ( Lo contrario )
print(f"> Not Verdadero = {not True}")
print(f"> Not Falso = {not False}")
print(f"> Not Falso o Verdadero = {not (False or True)}")


# Operadores de Texto


# Operadores de Comparación y de Identidad


# Operadores Lógicos


# Operadores de Pertenencia
mi_texto:str = "Lorem ipsum dolor sit amet consectetur adipiscing elit dui odio"
mi_sub_texto: str = "amet"
mi_otro_sub_texto: str = "pepito"

# Pertenece
print(f"> ¿amet está dentro del mi_texto?: {mi_sub_texto in mi_texto}")
# No Pertenece
print(f"> ¿pepito no está dentro de mi_texto?: {mi_otro_sub_texto not in mi_texto}")

# Operadores de Asignación




# Operadores de Bits




'''
CONDICIONALES
'''
# IF


# IF - ELSE


# IF - ELIF - ELSE
'''En Python, la estructura es con "elif" y no con "else if"''' 
miEdad: int = 31
if (miEdad >= 60):    
  print('Apuntarse al gym')
elif (miEdad < 60 and miEdad > 30): 
  print ('Adulto maduro')
elif (miEdad == 31):    
  print ('Adulto en su sweet moment')
elif (miEdad < 30 and miEdad >= 18):    
  print ('Adulto joven, todo en orden')
else:    print ('¡A clase!')

# SWITCH CASE ----> ¡¡¡¡¡ PYTHON NO DISPONE DE UN SWITCH CASE como otros lenguajes !!!!!


'''
BUCLES
'''

lista = [1,2,3,4,5,6,7,8] 
for elemento in lista:    
  if(elemento % 2 == 0):
    break        
    print(f'{elemento} es par')
  else:        
    print(f'{elemento} es impar')
    continue

print(elemento)


# Variables Globales para el programa


# Inicialización de Variables


# Bucle FOR para sacar valores del 0 al 100


# Bucle FOR sacar los elementos pares e impares de la lista


# Bucle WHILE para encontrar eliminar elementos hasta que la longitud sea 3
lista = [1,2,3,4,5,6,7,8] 
# Bucle WHILE para encontrar eliminar elementos hasta que la longitud sea 3
while (len(lista) > 3):    
  lista.pop(2)    
  print(lista)


# Python NO CUENTA con bucles DO - WHILE, pero se pueden simular:

# Bucle WHILE INFINITO - ¡OJO!
# ¡Bucle INFINITO! Mucho cuidado
'''
suma: int = 0
while True:    
  suma+=1    
  print(suma)
'''
# Python NO CUENTA con bucles DO - WHILE, pero se pueden simular:
i = 1   
while True:     
  print(i)      
  i = i + 1      
  if(i > 5):          
    break

'''
FUNCIONES
'''
# Funciones básicas
# Función Básica
def miFuncion():  
  print(f"Esto es una función básica")
  # contenido de la función

# Contenido qu no pertenece la función

# Llamamdo y ejecutando la función
miFuncion()

	
# Función con Parámetros No Tipados
def miFuncionConParametros(a,b):
    print(f"¡{a}, {b}!")

def miFuncionConParametros2(a,b):
    print(f"¡{a * b}!")
 
# llamando la función y pasándole algunos parámetros
miFuncionConParametros('Hola', 'Mundo')
miFuncionConParametros('Adiós', 'Mundo')
miFuncionConParametros(1,2)

# miFuncionConParametros2('Adiós', 'Mundo')
# miFuncionConParametros2(1,2)

# llamando la función y pasándole algunos parámetros

# Función con Parámetros Tipados
def miFuncionConParametrosTipados(a: str, b: str) :
    print(f"¡{a}, {b}!")
 
 
# llamando la función y pasándole algunos
# parámetros tipados
miFuncionConParametrosTipados('Hola', 'Mundo')
miFuncionConParametrosTipados(1,2)

# llamando la función y pasándole algunos
# parámetros tipados


# Función con parámetros por defecto
# Si un valor no viene, se pone por defecto
	
# Si un valor no viene, se pone por defecto
def miFuncionConParametrosPorDefecto(a, b = 1) :
    print(f"La división es {a/b}")
 
 
# llamando la función y pasándole los dos parámetros
miFuncionConParametrosPorDefecto(3, 4)
miFuncionConParametrosPorDefecto(a=3, b=4)
miFuncionConParametrosPorDefecto(b=3, a=4)
# llamando la función y pasándole un único parámetro
miFuncionConParametrosPorDefecto(3)

# llamando la función y pasándole los dos parámetros

# llamando la función y pasándole un único parámetro

''' NOTA: PARÁMETROS OPCIONALES:
    Python NO dispone de parámetros opcionales. Únicamente se hace uso de
    los parámetros por defecto en su lugar.
'''

# Función con muchos parámetros
	
def miFuncionConMultiplesParametros(*elementos) :
    for elemento in elementos:
        print(f"Elemento: {elemento}")
 
# llamando la función y pasándole una lista de parámetros
miFuncionConMultiplesParametros(1,2,3)
miFuncionConMultiplesParametros(1,2,3,4,5)
lista: [int] = [10,9,8,7]
miFuncionConMultiplesParametros(*lista, 6,5,4)


# llamando la función y pasándole una lista de parámetros

# Función con Retorno
	
def miFuncionConRetorno():
    return '¡Hola, Mundo!'
 
# llamando, ejecutando y almacenando el retorno en una variable
# la variable hola_mundo acabará valiendo "¡Hola, Mundo!"
hola_mundo = miFuncionConRetorno()
print(hola_mundo)

print(miFuncionConRetorno())

# llamando, ejecutando y almacenando el retorno en una variable
# la variable hola_mundo acabará valiendo "¡Hola, Mundo!"


# Función con Retorno Tipado
def miFuncionConRetornoTipado(*elementos) -> int :
    # Inicializamos la variable suma a 0 para incrementarla después
    suma: int = 0
 
    # iteramos sobre los elementos y los vamos sumando uno a uno
    # los guardamos en la variable suma que se va incrementando
    for elemento in elementos:
        print(f"Elemento: {elemento}")
        suma += elemento
 
    return suma
 
# llamar, pasarle la lista, ejecutar y almacenar la suma del retorno
# en la variable sumatorio
lista_numeros = [1, 2, 3, 4, 5, 6]
sumatorio = miFuncionConRetornoTipado(*lista_numeros)
print(f"EL sumatorio total es: {sumatorio}")

	
''' PASO POR REFERENCIA
Paso de parámetros por Referencia
 
Los valores simples se pasan, por defecto, por valor
Los valores complejos se pasan, por defecto, por referencia
 
'''
 
# las listas al ser complejos se pasan por referencia
# Esto quiere decir que si la función edita el parámetro,
# éste se edita también en origen
 
def doblar_valores(numeros):
    for i,n in enumerate(numeros):
        numeros[i] *= 2

# definiendo una variable que se va a pasar por referencia
ns = [10,50,100]
doblar_valores(ns)
print(f"Lista Original Modificada: {ns}") #[20, 100, 200]

	
# SI NO QUEREMOS PASAR UNA LISTA COMO REFERENCIA, DEBEMOS REALIZAR UNA COPIA "AL VUELO"
# Ahora esta no se pasará por referencia, ya que haremos una copia del valor
ns = [10,50,100]
doblar_valores(ns[:])  # Una copia al vuelo de una lista se realiza con [:]
# Esto hace que la lista original no se vea modificada
print(f"Lista Original No Modificada: {ns}") #[10, 50, 100]

	
# Para aquellos tipos de datos simples, si queremos el mismo comportamiento
# de paso por referencia podemos:
 
# SOBRESCRIBIR EL VALOR ORIGINAL CON EL VALOR DE RETURN DE LA FUNCIÓN
def doblar_valor(numero):
    return numero * 2
 
n = 10
doblar_valor(n)
n = doblar_valor(n)
print(f"Valor original: {n}")


	
''' FUNCIONES LAMBDA:
 
Las funciones Lambda de Python son bastante habituales.
 
'''
 
al_cuadrado = lambda a: a**2
 
# llamando a la función lambda
print(al_cuadrado(2)) # imprimirá un 4

# llamar, pasarle la lista, ejecutar y almacenar la suma del retorno
# en la variable sumatorio


# Pasando Diccionarios por parámetro


# llamando la función y pasándole una diccionario como parámetros


''' FUNCIONES LAMBDA:

Las funciones Lambda de Python son bastante habituales.

Básicamente sirven para definir funciones rápidas para un consumo veloz

Son muy parecidas a las funciones flecha de TypeScript
'''

# llamando a la función lambda



# las listas al ser complejos se pasan por referencia
# Esto quiere decir que si la función edita el parámetro,
# éste se edita también en origen


# definiendo una variable que se va a pasar por referencia


# Para aquellos tipos de datos simples, si queremos el mismo comportamiento
# de paso por referencia podemos:

# SOBRESCRIBIR EL VALOR ORIGINAL CON EL VALOR DE RETURN DE LA FUNCIÓN

# SI NO QUEREMOS PASAR UNA LISTA COMO REFERENCIA, DEBEMOS REALIZAR UNA COPIA "AL VUELO"
# Ahora esta no se pasará por referencia, ya que haremos una copia del valor


# Esto hace que la lista original no se vea modificada



'''
LISTAS
'''

'''
DICCIONARIOS
'''


'''
FECHAS
'''

import datetime
import time
import calendar
# import locale

# locale.setlocale(locale.LC_ALL,'es_ES')

print('Fecha y Hora Actual:', datetime.datetime.now())
print('Fecha actual', datetime.date.today())
print('Año actual:', datetime.date.today().strftime("%Y"))
print('Mes actual:', datetime.date.today().strftime("%B"))
print('Mes actual(num):', datetime.date.today().strftime("%m"))
print('Número de la semana del año:', datetime.date.today().strftime("%W"))
print('Día del año:', datetime.date.today().strftime("%j"))
print('Día del mes:', datetime.date.today().strftime("%d"))
print('Día de la semana:', datetime.date.today().strftime("%A"))


print('Día:', calendar.day_name[0])
print('Mes:', calendar.month_name[10])
print('2020 es bisisesto?:', calendar.isleap(2020))


ahora = datetime.datetime.now()
# timeStamp = time.mktime(ahora.timestamp())
timeStamp = time.mktime(ahora.timetuple())

print('TimeStamp', timeStamp)

# Formato de timeStamp legible
print('Fecha Legible:',datetime.datetime.fromtimestamp(timeStamp).strftime('%Y-%m-%d %H:%M:%S'))

miFecha = '02/10/2021'

nuevoTimeStamp = time.mktime(datetime.datetime.strptime(miFecha,'%d/%m/%Y').timetuple())

print('Nuevo TimeStamp', nuevoTimeStamp)