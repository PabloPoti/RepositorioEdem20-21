import pandas as pd

# CSV
pokemon_df = pd.read_csv('pokemon_data.csv', dtype={"Name": str, "Type 1": str, "Speed": int,"Generation": str,})

#EXCEL
#pokemon_df_excel = pd.read_excel('pokemon_data.xlsx')

#TXT con tabulación
#pokemon_df_txt = pd.read_csv('pokemon_data.txt', delimiter='\t')

'''
IMPRIMIR VALORES
'''
print(pokemon_df)

'''
IMPRIMIR 5 PRIMEROS
'''
print(pokemon_df.head(5))

'''
IMPRIMIR 5 ÚLTIMOS
'''
print(pokemon_df.tail(5))

'''
OBTENER NOMBRES DE COLUMNAS
'''
print(pokemon_df.columns)

'''
OBTENER VALORES COLUMNA NAME
'''
print(pokemon_df["Name"])

'''
OBTENER TODOS LOS NOMBRES
'''
nombres = pokemon_df['Name']
print(nombres)

'''
OBTENER TODOS LOS NOMBRES Y VELOCIDADES
'''
nombres_velocidades = pokemon_df[['Name', 'Speed']]
print(nombres_velocidades)

'''
OBTENER LOS PRIMEROS 5 NOMBRES
'''
#1ªForma
print(nombres.head(5))
#2ªForma
primeros_5 = pokemon_df['Name'][0:5]
print(primeros_5)

'''
OBTENER FILAS
'''
print('FILA 0:')
print(pokemon_df.iloc[0])

'''
OBTENER VARIAS FILAS
'''
print('FILA 0 HASTA 3:')
print(pokemon_df.iloc[0:3])

'''
OBTENER EL NOMBRE DE LA FILA 10
'''
print(pokemon_df.iloc[10, 1])

'''
ITERAR POR TODOS Y MOSTRAR EL ÍNDICE Y NOMBRE DE CADA
'''
for i, pokemon in pokemon_df.iterrows():
  print(i, pokemon['Name'])

'''
NOMBRES POKEMON TIPO 1 (AGUA)
'''
#loc = localiza
print(pokemon_df.loc[pokemon_df['Type 1'] == 'Water'])

'''
ESTADÍSTICAS
'''
print(pokemon_df.describe())

'''
ORDENACIÓN
'''
print(pokemon_df.sort_values('Name', ascending=True))

'''
ORDENACIÓN MÁS COMPLEJA
'''
print(pokemon_df.sort_values(['Type 1', 'HP'], ascending=[True, False])[['Name', 'Type 1', 'HP']])

'''
CREAR UNA COLUMNA EXTRA CALCULADA
'''
pokemon_df['Total'] = pokemon_df['HP'] + pokemon_df['Attack'] +pokemon_df['Defense'] +pokemon_df['Speed']

print(pokemon_df['Total'])

'''
MOSTRAR LOS 5 MEJORES
'''
print(pokemon_df.sort_values('Total', ascending=False).head(5)[['Name', 'Total']])

'''
ELIMINAR LA COLUMNA TOTAL
'''
#pokemon_df = pokemon_df.drop(columns=['Total'])